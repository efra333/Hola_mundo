﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLAYGROUND
{
    public class Mesh
    {
        public List<Triangle> Triangles;
        public List<Vertex> Vertex;
        public Mesh(List<Triangle> Triangles, List<Vertex> Vertex) 
        { 
        this.Triangles = Triangles;
        this.Vertex = Vertex;
        }
    }
}
