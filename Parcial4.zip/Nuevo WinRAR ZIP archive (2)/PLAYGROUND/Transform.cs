﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Reflection;
using static System.Windows.Forms.AxHost;
using System.Runtime.ExceptionServices;

namespace PLAYGROUND
{
    public class Transform
    {
        public float centerX = 0;
        public float centerY = 0;
        public float centerZ = 0;
        public float rotateAngleX = 0;
        public float rotateAngleY = 0;
        public float rotateAngleZ = 0;
        public float scale = 10;
        public int axis = 0;
        public PointF centroid;
        public PointF canvasCenter;
        public Transform() 
        {
            canvasCenter.X = MyForm.centerCanv.X;
            canvasCenter.Y = MyForm.centerCanv.Y;
        }
        public List<Vertex> TransformedPoints3D(List<Vertex> puntos3D, Vertex center, 
            float rotateAngleX = 0, float rotateAngleY = 0, float rotateAngleZ = 0, float scale3D = 5)
        {
            this.centerX =  center.X;
            this.centerY =  center.Y; 
            this.centerZ =  center.Z;
            this.rotateAngleX = rotateAngleX;
            this.rotateAngleY = rotateAngleY;
            this.rotateAngleZ = rotateAngleZ;

            // Rotación en 3D
            puntos3D = Rotate3D(puntos3D);

            // Traslación en 3D
            puntos3D = Translate3D(puntos3D, new Vertex(centerX, centerY, centerZ));

            // Escalación en 3D
            puntos3D = Scale3D(puntos3D, (scale3D*100));

            return puntos3D;
        }

        public List<Vertex> TransformedPoints3DPlanet(List<Vertex> puntos3D, Vertex center,
    float rotateAngleX = 0, float rotateAngleY = 0, float rotateAngleZ = 0, float scale3D = 10)
        {
            this.centerX = center.X;
            this.centerY = center.Y;
            this.centerZ = center.Z;
            this.rotateAngleX = rotateAngleX;
            this.rotateAngleY = rotateAngleY;
            this.rotateAngleZ = rotateAngleZ;

            // Traslación en 3D
            puntos3D = Translate3D(puntos3D, new Vertex(centerX, centerY, centerZ));

            // Rotación en 3D
            puntos3D = Rotate3D(puntos3D);

            // Escalación en 3D
            puntos3D = Scale3D(puntos3D, scale3D);

            return puntos3D;
        }

        public List<PointF> TransformedPoints2D(List<Vertex> puntos3D, float scale = 5)
        {
            this.scale = scale;

            //proyeccion nueva
            List<PointF> points = PerspectivaNueva(puntos3D);

            //2D DIMENSION
            for (int i = 0; i < points.Count; i++) { 
                //translate
                //points[i] = Translate(points[i]);
                //escalate 
                //points[i] = Scale(points[i], scale);
                //translate to center
                points[i] = TranslateToCenter(points[i]);
            }
            return points;
        }

        float viewportWidth = Canvas.canvasWidth, viewportHeight = Canvas.canvasHeight;
        int canvasWidth = Canvas.canvasWidth, canvasHeight = Canvas.canvasHeight;
        private PointF ViewportToCanvas(float x, float y)
        {
            return new PointF(x * canvasWidth / viewportWidth, y * canvasHeight / viewportHeight);
        }

        private PointF ProjectVertex(Vertex v)
        {
            if (Math.Abs(10f - v.Z) < float.Epsilon)
            {
                return PointF.Empty;
            }
            else
            {
                float d = 1 / (10f - v.Z);
                return ViewportToCanvas(v.X * d, v.Y * d);
            }
        }

        private List<PointF> PerspectivaNueva(List<Vertex> puntos3D)
        {
            List<PointF> points = new List<PointF>(puntos3D.Count);

                for (int i = 0; i < puntos3D.Count; i++)
                {
                    Vertex puntoActual = puntos3D[i];
                    PointF projected = ProjectVertex(puntoActual);
                        points.Add(projected);

                }

            return points;
        }

        private List<Vertex> Translate3D(List<Vertex> vertices, Vertex vector)
        {
            for(int i = 0; i < vertices.Count; i++)
            {
                vertices[i].X += vector.X;
                vertices[i].Y += vector.Y;
                vertices[i].Z += vector.Z;
            }
            return vertices;
        }

        private List<Vertex> Rotate3D(List<Vertex> puntos3D)
        {
            float angleX = rotateAngleX / 57.2958f; // Conversión de grados a radianes
            float angleY = rotateAngleY / 57.2958f; // Conversión de grados a radianes
            float angleZ = rotateAngleZ / 57.2958f; // Conversión de grados a radianes
            Vertex[] puntos3DModificados = new Vertex[puntos3D.Count];

            for (int i = 0; i < puntos3D.Count; i++)
            {
                Vertex puntoActual = puntos3D[i];
                Vertex puntoRotado = Rot.Rota(angleX, puntoActual, 0);
                puntoRotado = Rot.Rota(angleY, puntoRotado, 1);
                puntoRotado = Rot.Rota(angleZ, puntoRotado, 2);
                puntos3DModificados[i] = puntoRotado;  // Asignación directa al arreglo predefinido
            }

            return new List<Vertex>(puntos3DModificados); // Convertir el arreglo a lista si se necesita lista
        }

        private List<Vertex> Scale3D(List<Vertex> vertices, float scale)
        {
            Parallel.For(0, vertices.Count, i =>
            {
                vertices[i].X *= scale;
                vertices[i].Y *= scale;
                //vertices[i].Z *= scale;
            });
            return vertices;
        }

        private PointF TranslateToCenter(PointF punto)
        {
            punto.X = punto.X + canvasCenter.X + 0;
            punto.Y = canvasCenter.Y - punto.Y - 0;
            return punto;
        }
        public PointF Translate(PointF punto)
        {
            punto.X = punto.X - centroid.X;
            punto.Y = punto.Y - centroid.Y;
            return punto;
        }
        public PointF Scale(PointF punto, float scaleFactor)
        {
            punto.X *= scaleFactor * 100;
            punto.Y *= scaleFactor * 100;
            return punto;
        }
    }
}
