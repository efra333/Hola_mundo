﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLAYGROUND
{
    public partial class MyForm : Form
    {
        Canvas canvas;
        Scene scene;
        public static bool lines = false;
        public static bool grads = true;
        public static bool conv = false;
        public static PointF centerCanv;
        public static int res = 1;
        public static Color defCol = Color.Green;
        public static bool changeInvert = false;
        public static bool sp = true;
        public static Vertex iluminacion = new Vertex(0, 0, 1);
        public static float iluminacionIntensidad = 1.0f;
        public static int index = 0;


        int numberOfFigures = 0;
        int alphaX = 0, alphaY = 0, alphaZ = 0;
        float escala = 5;
        float centroideX = 0;
        float centroideY = 0;
        float centroideZ = 0;
        int[] ejeR = { 0, 0, 0 };

        public MyForm()
        {
            InitializeComponent();
        }

        private void Init()
        {
            PictureBoxCanv.SetBounds(pan1.Width + 4, panHead.Height + 4,
                Width - pan1.Width - pan2.Width - 24,
                Height - panHead.Height - PNL_BOTTOM.Height - 72);

            
            canvas = new Canvas(PictureBoxCanv);
            scene = new Scene();
            centerCanv = new PointF(PictureBoxCanv.Width / (2), PictureBoxCanv.Height / (2));
            ScaleNumeric.Value = 5;

            GradientCheck.Checked = true;
            //LineCheck.Checked = false;
            //undroll.Checked = true;
            
        }

        private void MyForm_SizeChanged(object sender, EventArgs e)
        {
            Init();
        }

        public void Render()
        {
            canvas.Render(scene);
        }
        float elapsed = 0;

        private void TIMER_Tick(object sender, EventArgs e)
        {

          /*  if (rotsl.Checked)
            {
                iluminacion.RotateY(1);
            }
            if (rotx.Checked)
            {
                iluminacion.RotateX(1);
            }
            if (rotz
                .Checked)
            {
                iluminacion.RotateZ(1);
            }*/

            if (checkInvert.Checked)
            {
                changeInvert = true;
            }
            else
            {
                changeInvert = false;
            }

            //if (LineCheck.Checked)
            //{
            //    lines = true;
            //}
            //else lines = false;

            if (GradientCheck.Checked)
            {
                grads = true;
            }
            else grads = false;

            //if (undroll.Checked)
            //{ 
            //    sp = true;
            //}
            //else sp = false;

            //if (Traslacional.Checked) 
            //{
            //    if (scene.Models.Count > 0)
            //    {
            //        if (!Animating)
            //        {
            //            elapsed += 0.5f;
            //            if (elapsed >= 1)
            //            {
            //                scene.Models[index].UpdateTransformPlanet(new Vertex(0.3f, 0, 0), 0, 5, 0, escala);
            //                elapsed = 0;
            //            }
            //        }
            //    }
            //}


            Render();
        }

        private void LoadBttn(object sender, EventArgs e)
        {
            if (!Animating)
            {
                OpenFileDialog openfilediag = new OpenFileDialog
                {
                    InitialDirectory = "c:\\",
                    Filter = "Todos los archivos (*.*)|*.*",
                    FilterIndex = 1,
                    RestoreDirectory = true
                };

                if (openfilediag.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        ReadObject reader = new ReadObject();
                        reader.path = openfilediag.FileName;
                        MessageBox.Show("Ruta del archivo seleccionado: " + reader.path);
                        reader.main();

                        if (reader.faces.Count > 0 && reader.vertices.Count > 0)
                        {
                            Mesh mesh = new Mesh(reader.faces, reader.vertices);
                            for (int i = 0; i < mesh.Triangles.Count; i++)
                            {
                                for (int j = 0; j < 3; j++)
                                {
                                    mesh.Triangles[i].Vertex.Add(mesh.Vertex[mesh.Triangles[i].Values[j]]);
                                    mesh.Triangles[i].OriginalVertex.Add(mesh.Vertex[mesh.Triangles[i].Values[j]]);
                                }
                            }
                 
                            Model model = new Model(mesh, new Vertex(0, 0, 0));
                            scene.Models.Add(model);
                            index = scene.Models.Count - 1;
                            numberOfFigures++;
                            listBox.Items.Add($"figura {index}");
                            //listBox1.Items.Add("Figure: " + numberOfFigures);
                            //listBox1.SelectedIndex = index;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al tratar de procesar file " + ex.Message);
                    }
                }
                else
                {
               
                    MessageBox.Show("No file lol");
                }
            }
        }

        private void SohereClicked(object sender, EventArgs e)
        {
            if (!Animating)
            {
                try
                {
                    ReadObject reader = new ReadObject();
                    reader.path = @"C:\Users\danim\Documents\Archivos\Videojuegos\OBJOTAS\sph.obj";
                    reader.main();

                    if (reader.faces.Count > 0 && reader.vertices.Count > 0)
                    {
                        Mesh mesh = new Mesh(reader.faces, reader.vertices);
                        for (int i = 0; i < mesh.Triangles.Count; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                mesh.Triangles[i].Vertex.Add(mesh.Vertex[mesh.Triangles[i].Values[j]]);
                                mesh.Triangles[i].OriginalVertex.Add(mesh.Vertex[mesh.Triangles[i].Values[j]]);
                            }
                        }
                        //scene.Models.Clear();
                        Model model = new Model(mesh, new Vertex(0, 0, 0));
                        scene.Models.Add(model);
                        index = scene.Models.Count - 1;
                        numberOfFigures++;
                        //listBox1.Items.Add("Figure: " + numberOfFigures);
                        //listBox1.SelectedIndex = index;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al procesar el archivo: " + ex.Message);
                }
            }
        }

        private void ValChangeNumScale(object sender, EventArgs e)
        {
            if (!Animating)
            {
                escala = (float)ScaleNumeric.Value;
                if (scene.Models.Count > 0)
                {
                    scene.Models[listBox.SelectedIndex].UpdateTransform(new Vertex(centroideX, centroideY, centroideZ), alphaX, alphaY, alphaZ, escala);
                }
            }
        }

        private void NumPosXChanged(object sender, EventArgs e)
        {
            if (!Animating)
            {
                centroideX = (float)NumericPositionX.Value;
                if (scene.Models.Count > 0)
                {
                    scene.Models[listBox.SelectedIndex].UpdateTransform(new Vertex(centroideX, centroideY, centroideZ), alphaX, alphaY, alphaZ, escala);
                }
            }
        }

        private void NumPosZChanged(object sender, EventArgs e)
        {
            if (!Animating)
            {
                centroideZ = (int)numericUpDownZ.Value;
                if (scene.Models.Count > 0)
                {
                    scene.Models[listBox.SelectedIndex].UpdateTransform(new Vertex(centroideX, centroideY, centroideZ), alphaX, alphaY, alphaZ, escala);
                }
            }
        }

        private void NumValChanged(object sender, EventArgs e)
        {
            if (!Animating)
            {
                centroideY = (float)NumericPositionY.Value;
                if (scene.Models.Count > 0)
                {
                    scene.Models[listBox.SelectedIndex].UpdateTransform(new Vertex(centroideX, centroideY, centroideZ), alphaX, alphaY, alphaZ, escala);
                }
            }
        }
        private void numUPDOWNAngle(object sender, EventArgs e)
        {
            if (!Animating)
            {
                if (AXISX.Checked) alphaX = (int)numericUpDownAngle.Value;
                if (AXISY.Checked) alphaY = (int)numericUpDownAngle.Value;
                if (AXISZ.Checked) alphaZ = (int)numericUpDownAngle.Value;
                if (scene.Models.Count > 0)
                {
                    scene.Models[index].UpdateTransform(new Vertex(centroideX, centroideY, centroideZ), alphaX, alphaY, alphaZ, escala);
                }
            }
        }

        private void MClicked(object sender, EventArgs e)
        {
            if (!Animating)
            {
                iluminacionIntensidad += 0.1f;
                //label7.Text = "" + iluminacionIntensidad;
            }
        }


        private void lisboxSel(object sender, EventArgs e)
        {
            if (!Animating) {
                //index = listBox1.SelectedIndex;
                if (index < 0) index = 0;
                centroideX = scene.Models[index].transform.centerX;
                centroideY = scene.Models[index].transform.centerY;
                centroideZ = scene.Models[index].transform.centerZ;
                escala = scene.Models[index].transform.scale;
                alphaX = (int)scene.Models[index].transform.rotateAngleX;
                alphaY = (int)scene.Models[index].transform.rotateAngleY;
                alphaZ = (int)scene.Models[index].transform.rotateAngleZ;

                NumericPositionX.Value = (decimal)centroideX;
                NumericPositionY.Value = (decimal)centroideY;
                numericUpDownZ.Value = (decimal)centroideZ;
                ScaleNumeric.Value = (decimal)escala;

                if (AXISX.Checked) numericUpDownAngle.Value = (decimal)alphaX;
                if (AXISY.Checked) numericUpDownAngle.Value = (decimal)alphaY;
                if (AXISZ.Checked) numericUpDownAngle.Value = (decimal)alphaZ;
            }
        }

        private void CLEAR_Click(object sender, EventArgs e)
        {
            if (!Animating)
            {
                index = 0;
                //listBox1.Items.Clear();
                scene.Models.Clear();
                ScaleNumeric.Value = 5;
                numericUpDownAngle.Value = 0;
                numericUpDownZ.Value = 0;
                NumericPositionX.Value = 0;
                NumericPositionY.Value = 0;
            }
        }

        private void Botonmenos_Click(object sender, EventArgs e)
        {
            if (!Animating)
            {
                iluminacionIntensidad -= 0.1f;
               // label7.Text = "" + iluminacionIntensidad;
            }
        }

        private void Keyframe_Click(object sender, EventArgs e)
        {
            if (scene.Models.Count > 0)
            {
                if (!Animating)
                {
                    float keyframeCenterX = scene.Models[index].transform.centerX;
                    float keyframeCenterY = scene.Models[index].transform.centerY;
                    float keyframeCenterZ = scene.Models[index].transform.centerZ;
                    float scale = scene.Models[index].transform.scale;
                    float keyframeAngleX = scene.Models[index].transform.rotateAngleX;
                    float keyframeAngleY = scene.Models[index].transform.rotateAngleY;
                    float keyframeAngleZ = scene.Models[index].transform.rotateAngleZ;
                    Keyframe keyframe = new Keyframe(keyframeCenterX, keyframeCenterY, keyframeCenterZ, scale, keyframeAngleX, keyframeAngleY, keyframeAngleZ);
                    System.Diagnostics.Debug.WriteLine(keyframeCenterX + " " + keyframeCenterY + " " + keyframeCenterZ + " " +
                        scale + " " + keyframeAngleX + " " + keyframeAngleY + " " + keyframeAngleZ + " ");
                    scene.Models[index].keyframes.Add(keyframe);
                    //listBox1.Items[index] = "Figure: " + (index + 1) + " " + scene.Models[index].keyframes.Count + " Keyframe";
                }
            }
        }
        private void Animation_Click(object sender, EventArgs e)
        {
            if (scene.Models.Count > 0) {
                    if (!Animating)
                    {
                    for (int i = 0; i < scene.Models.Count; i++) 
                    {
                        if (scene.Models[i].keyframes.Count > 1)
                        {
                            Animacion animation = new Animacion(scene.Models[i].keyframes);
                            scene.Models[i].animation = animation;
                            float firstcenterX = scene.Models[i].keyframes[0].kCenterX;
                            float firstcenterY = scene.Models[i].keyframes[0].kCenterY;
                            float firstcenterZ = scene.Models[i].keyframes[0].kCenterZ;
                            float firstscale = scene.Models[i].keyframes[0].scale;
                            float firstangleX = scene.Models[i].keyframes[0].kAlphaX;
                            float firstangleY = scene.Models[i].keyframes[0].kAlphaY;
                            float firstangleZ = scene.Models[i].keyframes[0].kAlphaZ;

                            scene.Models[i].UpdateTransform(new Vertex(firstcenterX, firstcenterY, firstcenterZ),
                                firstangleX, firstangleY, firstangleZ, firstscale);

                            TimerAnimacion.Start();
                        }

                    }
                }     
            }

        }
        bool Animating = false;

        private void ClearKeyframe_Click(object sender, EventArgs e)
        {
           if(scene.Models.Count > 0)
            {
                if (scene.Models[listBox.SelectedIndex].keyframes.Count > 0) scene.Models[listBox.SelectedIndex].keyframes.Remove(scene.Models[listBox.SelectedIndex].keyframes.Last());
                //listBox1.Items[index] = "Figure: " + (index + 1) + " " + scene.Models[index].keyframes.Count + " Keyframe";
            }

        }
        private void buttonConvolucion_Click(object sender, EventArgs e)
        {
            if (!conv)
            {
                Bitmap bitmap = new Bitmap(canvas.bitmap);
                PictureBoxCanv.Image = BitProcess.ConvolucionOptimized(bitmap,
                    canvas.Width, canvas.Height);
                Invalidate();
                TIMER.Stop();
                conv = true;
            }
            else { 
                PictureBoxCanv.Image = canvas.bitmap;
                conv = false;
                TIMER.Start();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Unrolling_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void AXISY_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void MyForm_Load(object sender, EventArgs e)
        {

        }

        private void LBL_STATUS_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void PNL_BOTTOM_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GRADIENT_CHECKBOX_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Traslacional_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rotx_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkInvert_CheckedChanged(object sender, EventArgs e)
        {

        }

        bool allAnimationEnded = true;  
        private void TimerAnimacion_Tick(object sender, EventArgs e)
        {
            if (scene.Models.Count > 0)
            {
                Animating = true;
                allAnimationEnded = true;  

                for (int i = 0; i < scene.Models.Count; i++)
                {
                    if (scene.Models[i].animation != null)
                    {
                        if (scene.Models[i].animation.animTick < scene.Models[i].animation.end)
                        {
                            allAnimationEnded = false;
                            float currentCenterX = scene.Models[i].animation.centrosX[scene.Models[i].animation.animTick];
                            float currentCenterY = scene.Models[i].animation.CentrosY[scene.Models[i].animation.animTick];
                            float currentCenterZ = scene.Models[i].animation.centrosZ[scene.Models[i].animation.animTick];
                            float currentScale = scene.Models[i].animation.scale[scene.Models[i].animation.animTick];
                            float currentAngleX = scene.Models[i].animation.alphasX[scene.Models[i].animation.animTick];
                            float currentAngleY = scene.Models[i].animation.alphasY[scene.Models[i].animation.animTick];
                            float currentAngleZ = scene.Models[i].animation.alphasZ[scene.Models[i].animation.animTick];
                            scene.Models[i].UpdateTransform(new Vertex(currentCenterX, currentCenterY, currentCenterZ),
                                                            currentAngleX, currentAngleY, currentAngleZ, currentScale);
                            scene.Models[i].animation.animTick++;
                        }
                        else
                        {
                            scene.Models[i].animation.animationEnded = true;  
                        }
                    }
                }

                if (allAnimationEnded)
                {
                    Animating = false;
                    TimerAnimacion.Stop();
                }
            }
        }


    }
}
