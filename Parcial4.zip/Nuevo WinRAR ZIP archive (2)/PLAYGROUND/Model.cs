﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PLAYGROUND
{
    public class Model
    {
        public PointF position; 
        public Mesh mesh;
        public int angle;
        public Transform transform;
        public List<PointF> points;
        public List<Keyframe> keyframes;
        public Animacion animation;
        public Model(Mesh mesh, Vertex center) { 
            this.mesh = mesh;
            keyframes = new List<Keyframe>();
            points = new List<PointF>();
            transform = new Transform();

            for(int j = 0; j < mesh.Triangles.Count;j++)
            {

                    mesh.Triangles[j].Vertex = transform.TransformedPoints3D(mesh.Triangles[j].OriginalVertex, center);
                    mesh.Triangles[j].Vertex2D = transform.TransformedPoints2D(mesh.Triangles[j].Vertex);
                    mesh.Triangles[j].Edges();
                
            }

            //points = transform.GetTransformedPoints(ref mesh.Vertex);
        }

        public void UpdateTransform(Vertex center,
            float rotateAngleX = 0, float rotateAngleY = 0, float rotateAngleZ = 0, float scale = 10) {

            for (int j = 0; j < mesh.Triangles.Count; j++)
            {

                mesh.Triangles[j].Vertex = transform.TransformedPoints3D(mesh.Triangles[j].OriginalVertex, center,
                        rotateAngleX, rotateAngleY, rotateAngleZ, scale);
                    mesh.Triangles[j].Vertex2D.Clear();
                    mesh.Triangles[j].Vertex2D = transform.TransformedPoints2D(mesh.Triangles[j].Vertex, scale);
                    mesh.Triangles[j].Edges();
          
            }
            //points = transform.GetTransformedPoints(ref mesh.Vertex);
        }
        public void UpdateTransformPlanet(Vertex center,
        float rotateAngleX = 0, float rotateAngleY = 0, float rotateAngleZ = 0, float scale = 10)
        {

            for (int j = 0; j < mesh.Triangles.Count; j++)
            {

                mesh.Triangles[j].Vertex = transform.TransformedPoints3DPlanet(mesh.Triangles[j].Vertex, center,
                        rotateAngleX, rotateAngleY, rotateAngleZ, scale);
                mesh.Triangles[j].Vertex2D.Clear();
                mesh.Triangles[j].Vertex2D = transform.TransformedPoints2D(mesh.Triangles[j].Vertex, scale);
                mesh.Triangles[j].Edges();

            }
            //points = transform.GetTransformedPoints(ref mesh.Vertex);
        }
    }
}
