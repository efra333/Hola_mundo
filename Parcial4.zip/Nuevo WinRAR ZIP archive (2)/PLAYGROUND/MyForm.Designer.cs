﻿namespace PLAYGROUND
{
    partial class MyForm
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PNL_MAIN = new System.Windows.Forms.Panel();
            this.PictureBoxCanv = new System.Windows.Forms.PictureBox();
            this.pan2 = new System.Windows.Forms.Panel();
            this.AXISZ = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDownZ = new System.Windows.Forms.NumericUpDown();
            this.AXISX = new System.Windows.Forms.CheckBox();
            this.numericUpDownAngle = new System.Windows.Forms.NumericUpDown();
            this.NumericPositionY = new System.Windows.Forms.NumericUpDown();
            this.AXISY = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.NumericPositionX = new System.Windows.Forms.NumericUpDown();
            this.ScaleNumeric = new System.Windows.Forms.NumericUpDown();
            this.pan1 = new System.Windows.Forms.Panel();
            this.buttonConvolucion = new System.Windows.Forms.Button();
            this.checkInvert = new System.Windows.Forms.CheckBox();
            this.PNL_BOTTOM = new System.Windows.Forms.Panel();
            this.ClearKeyframe = new System.Windows.Forms.Button();
            this.Animation = new System.Windows.Forms.Button();
            this.Keyframe = new System.Windows.Forms.Button();
            this.panHead = new System.Windows.Forms.Panel();
            this.CLEAR = new System.Windows.Forms.Button();
            this.GradientCheck = new System.Windows.Forms.CheckBox();
            this.LOAD_BTN = new System.Windows.Forms.Button();
            this.TIMER = new System.Windows.Forms.Timer(this.components);
            this.TimerAnimacion = new System.Windows.Forms.Timer(this.components);
            this.listBox = new System.Windows.Forms.ListBox();
            this.PNL_MAIN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxCanv)).BeginInit();
            this.pan2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericPositionY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericPositionX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScaleNumeric)).BeginInit();
            this.pan1.SuspendLayout();
            this.PNL_BOTTOM.SuspendLayout();
            this.panHead.SuspendLayout();
            this.SuspendLayout();
            // 
            // PNL_MAIN
            // 
            this.PNL_MAIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.PNL_MAIN.Controls.Add(this.PictureBoxCanv);
            this.PNL_MAIN.Controls.Add(this.pan2);
            this.PNL_MAIN.Controls.Add(this.pan1);
            this.PNL_MAIN.Controls.Add(this.PNL_BOTTOM);
            this.PNL_MAIN.Controls.Add(this.panHead);
            this.PNL_MAIN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PNL_MAIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PNL_MAIN.ForeColor = System.Drawing.Color.Silver;
            this.PNL_MAIN.Location = new System.Drawing.Point(0, 0);
            this.PNL_MAIN.Margin = new System.Windows.Forms.Padding(4);
            this.PNL_MAIN.Name = "PNL_MAIN";
            this.PNL_MAIN.Size = new System.Drawing.Size(1604, 839);
            this.PNL_MAIN.TabIndex = 0;
            // 
            // PictureBoxCanv
            // 
            this.PictureBoxCanv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PictureBoxCanv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.PictureBoxCanv.Location = new System.Drawing.Point(275, 102);
            this.PictureBoxCanv.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBoxCanv.Name = "PictureBoxCanv";
            this.PictureBoxCanv.Size = new System.Drawing.Size(1056, 615);
            this.PictureBoxCanv.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBoxCanv.TabIndex = 6;
            this.PictureBoxCanv.TabStop = false;
            // 
            // pan2
            // 
            this.pan2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pan2.Controls.Add(this.listBox);
            this.pan2.Controls.Add(this.Keyframe);
            this.pan2.Controls.Add(this.ClearKeyframe);
            this.pan2.Controls.Add(this.Animation);
            this.pan2.Dock = System.Windows.Forms.DockStyle.Right;
            this.pan2.Location = new System.Drawing.Point(1337, 102);
            this.pan2.Margin = new System.Windows.Forms.Padding(4);
            this.pan2.Name = "pan2";
            this.pan2.Size = new System.Drawing.Size(267, 613);
            this.pan2.TabIndex = 5;
            // 
            // AXISZ
            // 
            this.AXISZ.AutoSize = true;
            this.AXISZ.Location = new System.Drawing.Point(885, 59);
            this.AXISZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AXISZ.Name = "AXISZ";
            this.AXISZ.Size = new System.Drawing.Size(97, 33);
            this.AXISZ.TabIndex = 7;
            this.AXISZ.Text = "Eje  Z";
            this.AXISZ.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 331);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 29);
            this.label5.TabIndex = 7;
            this.label5.Text = "Z";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(126, 236);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 29);
            this.label3.TabIndex = 4;
            this.label3.Text = "Y";
            // 
            // numericUpDownZ
            // 
            this.numericUpDownZ.Location = new System.Drawing.Point(64, 331);
            this.numericUpDownZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numericUpDownZ.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.numericUpDownZ.Minimum = new decimal(new int[] {
            6,
            0,
            0,
            -2147483648});
            this.numericUpDownZ.Name = "numericUpDownZ";
            this.numericUpDownZ.Size = new System.Drawing.Size(120, 34);
            this.numericUpDownZ.TabIndex = 8;
            this.numericUpDownZ.ValueChanged += new System.EventHandler(this.NumPosZChanged);
            // 
            // AXISX
            // 
            this.AXISX.AutoSize = true;
            this.AXISX.Location = new System.Drawing.Point(573, 62);
            this.AXISX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AXISX.Name = "AXISX";
            this.AXISX.Size = new System.Drawing.Size(100, 33);
            this.AXISX.TabIndex = 6;
            this.AXISX.Text = "Eje  X";
            this.AXISX.UseVisualStyleBackColor = true;
            // 
            // numericUpDownAngle
            // 
            this.numericUpDownAngle.Location = new System.Drawing.Point(573, 18);
            this.numericUpDownAngle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numericUpDownAngle.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.numericUpDownAngle.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.numericUpDownAngle.Name = "numericUpDownAngle";
            this.numericUpDownAngle.Size = new System.Drawing.Size(120, 34);
            this.numericUpDownAngle.TabIndex = 4;
            this.numericUpDownAngle.ValueChanged += new System.EventHandler(this.numUPDOWNAngle);
            // 
            // NumericPositionY
            // 
            this.NumericPositionY.Location = new System.Drawing.Point(64, 234);
            this.NumericPositionY.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NumericPositionY.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.NumericPositionY.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.NumericPositionY.Name = "NumericPositionY";
            this.NumericPositionY.Size = new System.Drawing.Size(120, 34);
            this.NumericPositionY.TabIndex = 5;
            this.NumericPositionY.ValueChanged += new System.EventHandler(this.NumValChanged);
            // 
            // AXISY
            // 
            this.AXISY.Location = new System.Drawing.Point(690, 59);
            this.AXISY.Margin = new System.Windows.Forms.Padding(4);
            this.AXISY.Name = "AXISY";
            this.AXISY.Size = new System.Drawing.Size(188, 39);
            this.AXISY.TabIndex = 3;
            this.AXISY.Text = "Eje  Y";
            this.AXISY.UseVisualStyleBackColor = true;
            this.AXISY.CheckedChanged += new System.EventHandler(this.AXISY_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1171, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Scale";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(125, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "X";
            // 
            // NumericPositionX
            // 
            this.NumericPositionX.Location = new System.Drawing.Point(64, 129);
            this.NumericPositionX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NumericPositionX.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NumericPositionX.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.NumericPositionX.Name = "NumericPositionX";
            this.NumericPositionX.Size = new System.Drawing.Size(120, 34);
            this.NumericPositionX.TabIndex = 3;
            this.NumericPositionX.ValueChanged += new System.EventHandler(this.NumPosXChanged);
            // 
            // ScaleNumeric
            // 
            this.ScaleNumeric.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.ScaleNumeric.Location = new System.Drawing.Point(1279, 8);
            this.ScaleNumeric.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ScaleNumeric.Maximum = new decimal(new int[] {
            25,
            0,
            0,
            0});
            this.ScaleNumeric.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.ScaleNumeric.Name = "ScaleNumeric";
            this.ScaleNumeric.Size = new System.Drawing.Size(120, 34);
            this.ScaleNumeric.TabIndex = 0;
            this.ScaleNumeric.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.ScaleNumeric.ValueChanged += new System.EventHandler(this.ValChangeNumScale);
            // 
            // pan1
            // 
            this.pan1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pan1.Controls.Add(this.CLEAR);
            this.pan1.Controls.Add(this.buttonConvolucion);
            this.pan1.Controls.Add(this.numericUpDownZ);
            this.pan1.Controls.Add(this.label5);
            this.pan1.Controls.Add(this.label2);
            this.pan1.Controls.Add(this.label3);
            this.pan1.Controls.Add(this.NumericPositionY);
            this.pan1.Controls.Add(this.NumericPositionX);
            this.pan1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan1.Location = new System.Drawing.Point(0, 102);
            this.pan1.Margin = new System.Windows.Forms.Padding(4);
            this.pan1.Name = "pan1";
            this.pan1.Size = new System.Drawing.Size(267, 613);
            this.pan1.TabIndex = 4;
            // 
            // buttonConvolucion
            // 
            this.buttonConvolucion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonConvolucion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonConvolucion.ForeColor = System.Drawing.Color.Black;
            this.buttonConvolucion.Location = new System.Drawing.Point(25, 513);
            this.buttonConvolucion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonConvolucion.Name = "buttonConvolucion";
            this.buttonConvolucion.Size = new System.Drawing.Size(215, 39);
            this.buttonConvolucion.TabIndex = 9;
            this.buttonConvolucion.Text = "Conv";
            this.buttonConvolucion.UseVisualStyleBackColor = true;
            this.buttonConvolucion.Click += new System.EventHandler(this.buttonConvolucion_Click);
            // 
            // checkInvert
            // 
            this.checkInvert.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.checkInvert.Location = new System.Drawing.Point(12, 20);
            this.checkInvert.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkInvert.Name = "checkInvert";
            this.checkInvert.Size = new System.Drawing.Size(215, 78);
            this.checkInvert.TabIndex = 8;
            this.checkInvert.Text = "Inver P -> P";
            this.checkInvert.UseVisualStyleBackColor = true;
            this.checkInvert.CheckedChanged += new System.EventHandler(this.checkInvert_CheckedChanged);
            // 
            // PNL_BOTTOM
            // 
            this.PNL_BOTTOM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.PNL_BOTTOM.Controls.Add(this.checkInvert);
            this.PNL_BOTTOM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PNL_BOTTOM.Location = new System.Drawing.Point(0, 715);
            this.PNL_BOTTOM.Margin = new System.Windows.Forms.Padding(4);
            this.PNL_BOTTOM.Name = "PNL_BOTTOM";
            this.PNL_BOTTOM.Size = new System.Drawing.Size(1604, 124);
            this.PNL_BOTTOM.TabIndex = 3;
            this.PNL_BOTTOM.Paint += new System.Windows.Forms.PaintEventHandler(this.PNL_BOTTOM_Paint);
            // 
            // ClearKeyframe
            // 
            this.ClearKeyframe.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.ClearKeyframe.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClearKeyframe.ForeColor = System.Drawing.Color.IndianRed;
            this.ClearKeyframe.Location = new System.Drawing.Point(0, 375);
            this.ClearKeyframe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ClearKeyframe.Name = "ClearKeyframe";
            this.ClearKeyframe.Size = new System.Drawing.Size(253, 42);
            this.ClearKeyframe.TabIndex = 10;
            this.ClearKeyframe.Text = "Clear";
            this.ClearKeyframe.UseVisualStyleBackColor = false;
            this.ClearKeyframe.Click += new System.EventHandler(this.ClearKeyframe_Click);
            // 
            // Animation
            // 
            this.Animation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Animation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Animation.ForeColor = System.Drawing.Color.IndianRed;
            this.Animation.Location = new System.Drawing.Point(128, 329);
            this.Animation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Animation.Name = "Animation";
            this.Animation.Size = new System.Drawing.Size(127, 42);
            this.Animation.TabIndex = 9;
            this.Animation.Text = "Play";
            this.Animation.UseVisualStyleBackColor = false;
            this.Animation.Click += new System.EventHandler(this.Animation_Click);
            // 
            // Keyframe
            // 
            this.Keyframe.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Keyframe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Keyframe.ForeColor = System.Drawing.Color.IndianRed;
            this.Keyframe.Location = new System.Drawing.Point(3, 331);
            this.Keyframe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Keyframe.Name = "Keyframe";
            this.Keyframe.Size = new System.Drawing.Size(120, 39);
            this.Keyframe.TabIndex = 6;
            this.Keyframe.Text = "Set";
            this.Keyframe.UseVisualStyleBackColor = false;
            this.Keyframe.Click += new System.EventHandler(this.Keyframe_Click);
            // 
            // panHead
            // 
            this.panHead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panHead.Controls.Add(this.AXISZ);
            this.panHead.Controls.Add(this.GradientCheck);
            this.panHead.Controls.Add(this.LOAD_BTN);
            this.panHead.Controls.Add(this.AXISX);
            this.panHead.Controls.Add(this.label1);
            this.panHead.Controls.Add(this.numericUpDownAngle);
            this.panHead.Controls.Add(this.ScaleNumeric);
            this.panHead.Controls.Add(this.AXISY);
            this.panHead.Dock = System.Windows.Forms.DockStyle.Top;
            this.panHead.Location = new System.Drawing.Point(0, 0);
            this.panHead.Margin = new System.Windows.Forms.Padding(4);
            this.panHead.Name = "panHead";
            this.panHead.Size = new System.Drawing.Size(1604, 102);
            this.panHead.TabIndex = 0;
            // 
            // CLEAR
            // 
            this.CLEAR.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.CLEAR.ForeColor = System.Drawing.Color.Black;
            this.CLEAR.Location = new System.Drawing.Point(0, 6);
            this.CLEAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CLEAR.Name = "CLEAR";
            this.CLEAR.Size = new System.Drawing.Size(143, 42);
            this.CLEAR.TabIndex = 10;
            this.CLEAR.Text = "Borrar";
            this.CLEAR.UseVisualStyleBackColor = true;
            this.CLEAR.Click += new System.EventHandler(this.CLEAR_Click);
            // 
            // GradientCheck
            // 
            this.GradientCheck.AutoSize = true;
            this.GradientCheck.Location = new System.Drawing.Point(411, 11);
            this.GradientCheck.Margin = new System.Windows.Forms.Padding(4);
            this.GradientCheck.Name = "GradientCheck";
            this.GradientCheck.Size = new System.Drawing.Size(141, 33);
            this.GradientCheck.TabIndex = 2;
            this.GradientCheck.Text = "Gradiente";
            this.GradientCheck.UseVisualStyleBackColor = true;
            this.GradientCheck.CheckedChanged += new System.EventHandler(this.GRADIENT_CHECKBOX_CheckedChanged);
            // 
            // LOAD_BTN
            // 
            this.LOAD_BTN.ForeColor = System.Drawing.Color.Black;
            this.LOAD_BTN.Location = new System.Drawing.Point(12, 11);
            this.LOAD_BTN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LOAD_BTN.Name = "LOAD_BTN";
            this.LOAD_BTN.Size = new System.Drawing.Size(143, 41);
            this.LOAD_BTN.TabIndex = 0;
            this.LOAD_BTN.Text = "Cargar\r\n";
            this.LOAD_BTN.UseVisualStyleBackColor = true;
            this.LOAD_BTN.Click += new System.EventHandler(this.LoadBttn);
            // 
            // TIMER
            // 
            this.TIMER.Enabled = true;
            this.TIMER.Interval = 10;
            this.TIMER.Tick += new System.EventHandler(this.TIMER_Tick);
            // 
            // TimerAnimacion
            // 
            this.TimerAnimacion.Interval = 15;
            this.TimerAnimacion.Tick += new System.EventHandler(this.TimerAnimacion_Tick);
            // 
            // listBox
            // 
            this.listBox.ItemHeight = 29;
            this.listBox.Location = new System.Drawing.Point(42, 47);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(120, 91);
            this.listBox.TabIndex = 0;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // MyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1604, 839);
            this.Controls.Add(this.PNL_MAIN);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MyForm";
            this.Text = "Julián Álvarez y su norteño banda xd";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MyForm_Load);
            this.SizeChanged += new System.EventHandler(this.MyForm_SizeChanged);
            this.PNL_MAIN.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxCanv)).EndInit();
            this.pan2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericPositionY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericPositionX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScaleNumeric)).EndInit();
            this.pan1.ResumeLayout(false);
            this.pan1.PerformLayout();
            this.PNL_BOTTOM.ResumeLayout(false);
            this.panHead.ResumeLayout(false);
            this.panHead.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PNL_MAIN;
        private System.Windows.Forms.PictureBox PictureBoxCanv;
        private System.Windows.Forms.Panel pan2;
        private System.Windows.Forms.Panel pan1;
        private System.Windows.Forms.Panel PNL_BOTTOM;
        private System.Windows.Forms.Panel panHead;
        private System.Windows.Forms.Timer TIMER;
        private System.Windows.Forms.Button LOAD_BTN;
        private System.Windows.Forms.CheckBox GradientCheck;
        private System.Windows.Forms.CheckBox AXISY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown ScaleNumeric;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown NumericPositionX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown NumericPositionY;
        private System.Windows.Forms.Button Keyframe;
        private System.Windows.Forms.NumericUpDown numericUpDownZ;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDownAngle;
        private System.Windows.Forms.CheckBox AXISX;
        private System.Windows.Forms.CheckBox AXISZ;
        private System.Windows.Forms.Button CLEAR;
        private System.Windows.Forms.CheckBox checkInvert;
        private System.Windows.Forms.Button Animation;
        private System.Windows.Forms.Timer TimerAnimacion;
        private System.Windows.Forms.Button ClearKeyframe;
        private System.Windows.Forms.Button buttonConvolucion;
        private System.Windows.Forms.ListBox listBox;
    }
}

