﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLAYGROUND
{
    public class Scene
    {
        public List<Model> Models;
        public Scene() { 
        Models = new List<Model>(); 
        }
        public void RenderScene(Canvas canvas) 
        {
            Parallel.For(0, Models.Count, (i) =>
            {
                Renderer.RenderModel(Models[i], canvas);
            });
        }
    }
}
