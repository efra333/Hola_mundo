﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PLAYGROUND
{
    public class Vertex
    {
            public float X, Y, Z;

            public Vertex(float x, float y, float z)
            {
                X = x;
                Y = y;
                Z = z;
            }
            public void RotateX(float angle)
            {
                float radians = angle * (float)Math.PI / 180.0f;
                float cosTheta = (float)Math.Cos(radians);
                float sinTheta = (float)Math.Sin(radians);

                float newY = cosTheta * Y - sinTheta * Z;
                float newZ = sinTheta * Y + cosTheta * Z;

                Y = newY;
                Z = newZ;
            }

            public void RotateZ(float angle)
            {
                float radians = angle * (float)Math.PI / 180.0f;
                float cosTheta = (float)Math.Cos(radians);
                float sinTheta = (float)Math.Sin(radians);

                float newX = cosTheta * X - sinTheta * Y;
                float newY = sinTheta * X + cosTheta * Y;

                X = newX;
                Y = newY;
            }

            public void RotateY(float angle)
            {
                float radians = angle * (float)Math.PI / 180.0f; // Convertir grados a radianes
                float cosTheta = (float)Math.Cos(radians);
                float sinTheta = (float)Math.Sin(radians);

                float newX = cosTheta * X + sinTheta * Z;
                float newZ = -sinTheta * X + cosTheta * Z;

                X = newX;
                Z = newZ;
            }

            public Vertex Normalize()
            {
                float mag = (float)Math.Sqrt(X * X + Y * Y + Z * Z);
                return new Vertex(X / mag, Y / mag, Z / mag);
            }

            public static float Dot(Vertex a, Vertex b)
            {
                return a.X * b.X + a.Y * b.Y + a.Z * b.Z;
            }

            public static Vertex Cross(Vertex a, Vertex b)
            {
                return new Vertex(
                    a.Y * b.Z - a.Z * b.Y,
                    a.Z * b.X - a.X * b.Z,
                    a.X * b.Y - a.Y * b.X);
            }
            public float Distance(Vertex other)
            {
                return (float)Math.Sqrt(
                    (this.X - other.X) * (this.X - other.X) +
                    (this.Y - other.Y) * (this.Y - other.Y) +
                    (this.Z - other.Z) * (this.Z - other.Z));
            }
            public static float Cross2D(PointF a, PointF b) 
            {
                return a.X * b.Y - a.Y * b.X;
            }
            public static Vertex operator -(Vertex a, Vertex b)
            {
                return new Vertex(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
            }

        }
}
