﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLAYGROUND
{
    internal class Rot
    {
        static float[,] axis;
        public static Vertex Rota(float angle, Vertex p,int xyz) {
            Mtx Mat;
            float cos = (float)Math.Cos(angle);
            float sin = (float)Math.Sin(angle);

            if (xyz == 0)
            {
                axis = new float[,]
                {
                { 1, 0, 0 },
                 { 0, cos, -sin },
                 { 0, sin, cos }

                };
            } else if (xyz == 1)
            {
                axis = new float[,]
                {
                { cos, 0, sin },
                 { 0, 1, 0 },
                 { -sin, 0, cos }

                };
            }
            else if (xyz == 2)
            {
                axis = new float[,]
{
                { cos, -sin, 0 },
                 { sin, cos, 0 },
                 { 0, 0, 1 }
                };
            }
            Mat = new Mtx(axis);

            return Mat.Mul(p);
            }
        }      
    }

