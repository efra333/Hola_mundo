﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLAYGROUND
{
    internal class ReadObject
    {
        public  string path;
        public  List<Vertex> vertices = new List<Vertex>();
        public  List<Triangle> faces = new List<Triangle>();

        public ReadObject() { }
        public void main()
        {
            vertices.Clear();
            faces.Clear();
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.StartsWith("v "))
                        {
                            string[] parts = line.Split(' ');
                            float[] values = new float[3];
                            for (int i = 0; i < 3; i++)
                            {
                                values[i] = float.Parse(parts[i + 1]);
                            }
                            vertices.Add(new Vertex(values[0], values[1], values[2]));
                        }
                        else if (line.StartsWith("f "))
                        {
                            string[] parts = line.Split(' ');
                            int[] values = new int[3];
                            for (int i = 1; i <= 3; i++)
                            {
                                string[] faceParts = parts[i].Split('/');
                                values[i - 1] = int.Parse(faceParts[0]) - 1;
                            }
                            faces.Add(new Triangle(values[0], values[1], values[2]));
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Ocurrió un error al leer el archivo: " + e.Message);
            }
        }
    }
}
