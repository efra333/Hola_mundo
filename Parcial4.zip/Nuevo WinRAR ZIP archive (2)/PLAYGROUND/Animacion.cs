﻿using System.Collections.Generic;

namespace PLAYGROUND
{
    public class Animacion
    {
        public List<float> centrosX;
        public List<float> alphasX;
        public List<float> alphasY;
        public List<float> CentrosY;
        public List<float> scale;
        public List<float> alphasZ;
        public List<float> centrosZ;

        public int end = 0;
        public int animTick = 0;
        

        public bool animationEnded = false;
        public Animacion(List<Keyframe> keyframes) {
            centrosX = new List<float>();
            CentrosY = new List<float>();
            centrosZ = new List<float>();
            alphasY = new List<float>();
            alphasZ = new List<float>();
            scale = new List<float>();
            alphasX = new List<float>();
            

            float ConstanteInterpol = 1f / 180f;
           
            for (int j = 1; j < keyframes.Count; j++)
            {
                for (float t = 0; t <= 1; t += ConstanteInterpol)
                {
                    float currentCenterX = FigureInterpole(keyframes[j-1].kCenterX,
                    keyframes[j].kCenterX, t);
                    centrosX.Add(currentCenterX);

                    float currentCenterY = FigureInterpole(keyframes[j - 1].kCenterY,
                    keyframes[j].kCenterY, t);
                    CentrosY.Add(currentCenterY);

                    float currentCenterZ = FigureInterpole(keyframes[j - 1].kCenterZ,
                    keyframes[j].kCenterZ, t);
                    centrosZ.Add(currentCenterZ);

                    float currentScale = FigureInterpole(keyframes[j - 1].scale,
                    keyframes[j].scale, t);
                    scale.Add(currentScale);

                    float currentAngleX = FigureInterpole(keyframes[j - 1].kAlphaX,
                    keyframes[j].kAlphaX, t);
                    alphasX.Add(currentAngleX);

                    float currentAngleY = FigureInterpole(keyframes[j - 1].kAlphaY,
                    keyframes[j].kAlphaY, t);
                    alphasY.Add(currentAngleY);

                    float currentAngleZ = FigureInterpole(keyframes[j - 1].kAlphaZ,
                    keyframes[j].kAlphaZ, t);
                    alphasZ.Add(currentAngleZ);


                }

            }
            end = centrosX.Count;

        }


        private float FigureInterpole(float A, float B, float t)
        {
            
            float C = A + (B - A) * t;

            return C;
        }
    }
}
