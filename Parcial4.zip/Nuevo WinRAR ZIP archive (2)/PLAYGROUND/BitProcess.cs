﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLAYGROUND
{
    public class BitProcess
    {
        //private static byte a = 3;
        private static byte r = 2;
        private static byte g = 1;
        private static byte b = 0;

        static int[,] conv = {
            { -1, 0, 1 },
            { -2, 0 ,2 },
            { -1, 0, 1 }
            };
        static int factor = 1;
        static int offset = 0;

        public static Bitmap ConvolucionOptimized(Bitmap original, int width, int height)
        {
            Bitmap bitmapNuevo = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            BitmapData dataSrc = original.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            BitmapData dataDest = bitmapNuevo.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

            int bytesPerPixel = 3;
            unsafe
            {
                byte* ptrSrc = (byte*)dataSrc.Scan0;
                byte* ptrDest = (byte*)dataDest.Scan0;
                int stride = dataSrc.Stride;

                Parallel.For(1, height - 1, y =>
                {
                    for (int x = 1; x < width - 1; x++)
                    {
                        int sumaR = 0, sumaG = 0, sumaB = 0;

                        for (int a = -1; a <= 1; a++)
                        {
                            for (int b = -1; b <= 1; b++)
                            {
                                int idx = ((y + b) * stride) + ((x + a) * bytesPerPixel);
                                sumaR += ptrSrc[idx + 2] * conv[a + 1, b + 1];
                                sumaG += ptrSrc[idx + 1] * conv[a + 1, b + 1];
                                sumaB += ptrSrc[idx] * conv[a + 1, b + 1];
                            }
                        }

                        sumaR = Clamp((sumaR / factor) + offset);
                        sumaG = Clamp((sumaG / factor) + offset);
                        sumaB = Clamp((sumaB / factor) + offset);

                        int idxDest = (y * stride) + (x * bytesPerPixel);
                        ptrDest[idxDest + 2] = (byte)sumaR;
                        ptrDest[idxDest + 1] = (byte)sumaG;
                        ptrDest[idxDest] = (byte)sumaB;
                    }
                });
            }

            original.UnlockBits(dataSrc);
            bitmapNuevo.UnlockBits(dataDest);

            return bitmapNuevo;
        }

        public static Bitmap Convolucion(Bitmap original, int width, int height)
        {
            Color oColor;

            int sumaR = 0;
            int sumaG = 0;
            int sumaB = 0;

            Bitmap bitmapNuevo = new Bitmap(original);

            for (int x = 1; x < width - 1; x++)
            {
                for (int y = 1; y < height - 1; y++)
                {
                    sumaR = 0;
                    sumaG = 0;
                    sumaB = 0;

                    for (int a = -1; a < 2; a++)
                    {
                        for (int b = -1; b < 2; b++)
                        {
                                oColor = original.GetPixel(x + a, y + b);

                                sumaR = sumaR + (oColor.R * conv[a + 1, b + 1]);
                                sumaG = sumaG + (oColor.G * conv[a + 1, b + 1]);
                                sumaB = sumaB + (oColor.B * conv[a + 1, b + 1]);

                        }
                    }

                    sumaR = (sumaR / factor) + offset;
                    sumaG = (sumaG / factor) + offset;
                    sumaB = (sumaB / factor) + offset;

                    sumaR = Clamp(sumaR);
                    sumaG = Clamp(sumaG);
                    sumaB = Clamp(sumaB);

                    bitmapNuevo.SetPixel(x, y, Color.FromArgb(sumaR, sumaG, sumaB));

                }
            }

            return bitmapNuevo; // Devolver el nuevo array modificado
        }

        private static int Clamp(int value)
        {
            if (value < 0) return 0;
            if (value > 255) return 255;
            return value;
        }

        private static void ContrastePixel(byte[] bits, int div, int i, int idx, double alpha)
        {
            // Calcula el nuevo valor para cada canal, asegurando que el resultado esté en el rango 0-255.
            int redValue = Math.Min(255, Math.Max(0, (int)(alpha*(bits[(i * div) + idx + r]-128) + 128)));
            int greenValue = Math.Min(255, Math.Max(0, (int)(alpha*(bits[(i * div) + idx + g]-128) + 128)));
            int blueValue = Math.Min(255, Math.Max(0, (int)(alpha * (bits[(i * div) + idx + b] - 128) + 128)));

            // Actualiza los valores en el array de bytes de la imagen.
            bits[(i * div) + idx + r] = (byte)redValue;
            bits[(i * div) + idx + g] = (byte)greenValue;
            bits[(i * div) + idx + b] = (byte)blueValue;
        }

        private static void BrilloPixel(byte[] bits, int div, int i, int idx, double brillo)
        {
            // Calcula el nuevo valor para cada canal, asegurando que el resultado esté en el rango 0-255.
            int redValue = Math.Min(255, Math.Max(0, (int)(bits[(i * div) + idx + r] + brillo)));
            int greenValue = Math.Min(255, Math.Max(0, (int)(bits[(i * div) + idx + g] + brillo)));
            int blueValue = Math.Min(255, Math.Max(0, (int)(bits[(i * div) + idx + b] + brillo)));

            // Actualiza los valores en el array de bytes de la imagen.
            bits[(i * div) + idx + r] = (byte)redValue;
            bits[(i * div) + idx + g] = (byte)greenValue;
            bits[(i * div) + idx + b] = (byte)blueValue;
        }

        /*private static void PixelValue(byte[] bits, int div, int i, int idx, Histograma histograma)
        {
            int redValue = (int) bits[(i * div) + idx + r];
            int greenValue = (int) bits[(i * div) + idx + g];
            int blueValue = (int) bits[(i * div) + idx + b];

            histograma.Rfrequencies[redValue]++;
            histograma.Gfrequencies[greenValue]++;
            histograma.Bfrequencies[blueValue]++;
        }*/

        private static void InvertPixel(byte[] bits, int div, int i, int idx) 
        {
            bits[(i * div) + idx + r] = (byte)(255 - bits[(i * div) + idx + r]); 
            bits[(i * div) + idx + g] = (byte)(255 - bits[(i * div) + idx + g]); 
            bits[(i * div) + idx + b] = (byte)(255 - bits[(i * div) + idx + b]); 
        }

        private static void GrayPixel(byte[] bits, int div, int i, int idx) 
        {
            int newRed;
            int newBlue;
            int newGreen;

            newRed = (int)((bits[(i * div) + idx + r] * 0.299) + (bits[(i * div) + idx + g] * 0.587) + (bits[(i * div) + idx + b] * 0.114));
            newGreen = (int)((bits[(i * div) + idx + r] * 0.299) + (bits[(i * div) + idx + g] * 0.587) + (bits[(i * div) + idx + b] * 0.114));
            newBlue = (int)((bits[(i * div) + idx + r] * 0.299) + (bits[(i * div) + idx + g] * 0.587) + (bits[(i * div) + idx + b] * 0.114));

            newRed = Math.Min(255, newRed);
            newGreen = Math.Min(255, newGreen);
            newBlue = Math.Min(255, newBlue);

            bits[(i * div) + idx + r] = (byte)newRed;
            bits[(i * div) + idx + g] = (byte)newGreen;
            bits[(i * div) + idx + b] = (byte)newBlue;
        }

        private static void SepiaPixel(byte[] bits, int div, int i, int idx)
        {            
            int newRed;
            int newBlue;
            int newGreen;

            newRed      = (int)((bits[(i * div) + idx + r] * 0.393) + (bits[(i * div) + idx + g] * 0.769) + (bits[(i * div) + idx + b] * 0.189));
            newGreen    = (int)((bits[(i * div) + idx + r] * 0.349) + (bits[(i * div) + idx + g] * 0.686) + (bits[(i * div) + idx + b] * 0.168));
            newBlue     = (int)((bits[(i * div) + idx + r] * 0.272) + (bits[(i * div) + idx + g] * 0.534) + (bits[(i * div) + idx + b] * 0.131));

            newRed = Math.Min(255, newRed);
            newGreen = Math.Min(255, newGreen);
            newBlue = Math.Min(255, newBlue);
            
            bits[(i * div) + idx + r] = (byte)newRed;
            bits[(i * div) + idx + g] = (byte)newGreen;
            bits[(i * div) + idx + b] = (byte)newBlue;
        }

        public static byte[] Contraste(byte[] bits, double alpha)
        {
            int div = 16;

            Parallel.For(0, bits.Length / div, i => // unrolling 
            {
                ContrastePixel(bits, div, i, 0, alpha);
                ContrastePixel(bits, div, i, 4, alpha);
                ContrastePixel(bits, div, i, 8, alpha);
                ContrastePixel(bits, div, i, 12, alpha);
            });

            return bits;
        }

        public static byte[] Brillo(byte[] bits, double brillo)
        {
            int div = 16;

            Parallel.For(0, bits.Length / div, i => // unrolling 
            {
                BrilloPixel(bits, div, i, 0, brillo);
                BrilloPixel(bits, div, i, 4, brillo);
                BrilloPixel(bits, div, i, 8, brillo);
                BrilloPixel(bits, div, i, 12, brillo);
            });

            return bits;
        }

        /*public static byte[] CountFrequencies(byte[] bits, Histograma histograma)
        {
            int div = 16;

            Parallel.For(0, bits.Length / div, i => // unrolling 
            {
                PixelValue(bits, div, i, 0, histograma);
                PixelValue(bits, div, i, 4, histograma);
                PixelValue(bits, div, i, 8, histograma);
                PixelValue(bits, div, i, 12, histograma);
            });

            return bits;
        }*/

        public static byte[] Invert(byte[] bits) //modificar a bytes
        {
            int div = 16;

            Parallel.For(0, bits.Length / div, i => // unrolling 
            {
                InvertPixel(bits, div, i, 0);
                InvertPixel(bits, div, i, 4);
                InvertPixel(bits, div, i, 8);
                InvertPixel(bits, div, i, 12);
            });

            return bits;
        }

        public static byte[] Gray(byte[] bits)
        {
            int div = 16;
            Parallel.For(0, bits.Length / div, i => // unrolling 
            {               
                GrayPixel(bits, div, i, 0);
                GrayPixel(bits, div, i, 4);
                GrayPixel(bits, div, i, 8);
                GrayPixel(bits, div, i, 12);
            });

            return bits;
        }

        public static byte[] Sepia(byte[] bits)
        {
            int div = 16;

            Parallel.For(0, bits.Length / div, i => // unrolling 
            {
                SepiaPixel(bits, div, i, 0);
                SepiaPixel(bits, div, i, 4);
                SepiaPixel(bits, div, i, 8);
                SepiaPixel(bits, div, i, 12);
            });

            return bits;
        }

    }
}
