﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLAYGROUND
{
    public class Renderer
    {
        public static void RenderModel(Model model, Canvas canvas) 
        {
            if (MyForm.sp) {
                Parallel.For(0, (model.mesh.Triangles.Count), j =>
                {
                        Triangle trianglek = model.mesh.Triangles[j];

                        if (MyForm.grads)
                        {
                            ApplyGradientByDotProduct(ref trianglek);
                        }
                        else
                        {
                            trianglek.hs[0] = 1;
                            trianglek.hs[1] = 1;
                            trianglek.hs[2] = 1;
                        }

                        PointF edge1 = trianglek.edge1;
                        PointF edge2 = trianglek.edge2;
                        PointF edge3 = trianglek.edge3;
                        float crossProduct = Vertex.Cross2D(edge1, edge2) + Vertex.Cross2D(edge2, edge3) + Vertex.Cross2D(edge3, edge1);

                        if (crossProduct > 0) RenderFilledTriangleZBuffer(trianglek, canvas, MyForm.defCol);

                        if (MyForm.lines) if (crossProduct > 0) RenderTriangle(trianglek, canvas);

                });
            }
            else
            {
                for (int k = 0; k < model.mesh.Triangles.Count; k++)
                {
                    Triangle trianglek = model.mesh.Triangles[k];

                    if (MyForm.grads)
                    {
                        ApplyGradientByDotProduct(ref trianglek);
                    }
                    else
                    {
                        trianglek.hs[0] = 1;
                        trianglek.hs[1] = 1;
                        trianglek.hs[2] = 1;
                    }

                    RenderFilledTriangleZBuffer(trianglek, canvas, MyForm.defCol);

                    PointF edge1 = trianglek.edge1;
                    PointF edge2 = trianglek.edge2;
                    PointF edge3 = trianglek.edge3;

                    float crossProduct = Vertex.Cross2D(edge1, edge2) + Vertex.Cross2D(edge2, edge3) + Vertex.Cross2D(edge3, edge1);
                    if (MyForm.lines) if (crossProduct > 0) RenderTriangle(trianglek, canvas);
                }
            }
        }
        public static void ApplyGradientByDotProduct(ref Triangle trianglej)
        {
            Vertex A = trianglej.Vertex[0];
            Vertex B = trianglej.Vertex[1];
            Vertex C = trianglej.Vertex[2];

            MyForm.iluminacion = MyForm.iluminacion.Normalize();

            float dotAToLight = Vertex.Dot(A, MyForm.iluminacion) * 2 * (MyForm.iluminacionIntensidad);
            float dotBToLight = Vertex.Dot(B, MyForm.iluminacion) * 2 * (MyForm.iluminacionIntensidad);
            float dotCToLight = Vertex.Dot(C, MyForm.iluminacion) * 2 * (MyForm.iluminacionIntensidad);

            float h0 = dotAToLight;
            float h1 = dotBToLight;
            float h2 = dotCToLight;

            trianglej.hs[0] = h0;
            trianglej.hs[1] = h1;
            trianglej.hs[2] = h2;

        }
        public static void DrawLine(PointF p1, PointF p2, Vertex v1, Vertex v2, Color c, Canvas canvas)
        {
            if (Math.Abs(p2.X - p1.X) > Math.Abs(p2.Y - p1.Y))
            {
                if (p1.X > p2.X)
                {
                    PointF temp = p1;
                    p1 = p2;
                    p2 = temp;
                }
                List<float> ys = Interpolate(p1.X, p1.Y, p2.X, p2.Y);
                List<float> zs = Interpolate(p1.X, v1.Z, p2.X, v2.Z);
                for (int x = (int)p1.X; x < p2.X; x++)
                {
                    int currentY = (int)ys[x - (int)p1.X];
                    canvas.DrawPixel(x, currentY, c);
                }
            }
            else
            {
                if (p1.Y > p2.Y)
                {
                    PointF temp = p1;
                    p1 = p2;
                    p2 = temp;
                }
                List<float> xs = Interpolate(p1.Y, p1.X, p2.Y, p2.X);
                List<float> zs = Interpolate(p1.Y, v1.Z, p2.Y, v2.Z);
                for (int y = (int)p1.Y; y < p2.Y; y++)
                {
                    int currentX = (int)xs[y - (int)p1.Y];
                    canvas.DrawPixel(currentX, y, c);
                }
            }
        }
        public static void RenderTriangle(Triangle triangle, Canvas canvas)
        {
            Color color = Color.Red;

            Vertex V0 = triangle.Vertex[0];
            Vertex V1 = triangle.Vertex[1];
            Vertex V2 = triangle.Vertex[2];

            PointF P0 = triangle.Vertex2D[0];
            PointF P1 = triangle.Vertex2D[1];
            PointF P2 = triangle.Vertex2D[2];

            DrawLine(P0,P1,V0,V1,color, canvas);
            DrawLine(P1, P2,V1,V2, color, canvas);
            DrawLine(P2, P0,V2,V0,color, canvas);

        }
        public static void RenderFilledTriangleZBuffer(Triangle triangle, Canvas canvas, Color colorBase)
        {
            PointF P0 = triangle.Vertex2D[0];
            float h0 = triangle.hs[0];
            float z0 = triangle.Vertex[0].Z;
            PointF P1 = triangle.Vertex2D[1];
            float h1 = triangle.hs[1];
            float z1 = triangle.Vertex[1].Z;
            PointF P2 = triangle.Vertex2D[2];
            float h2 = triangle.hs[2];
            float z2 = triangle.Vertex[2].Z;

            SortByY2(ref P0, ref P1, ref P2, ref h0, ref h1, ref h2, ref z0, ref z1, ref z2);

            float y0 = P0.Y;
            float x0 = P0.X;

            float y1 = P1.Y;
            float x1 = P1.X;

            float y2 = P2.Y;
            float x2 = P2.X;


            List<float> xlinea01 = Interpolate(y0, x0, y1, x1);
            List<float> h01 = Interpolate(y0, h0, y1, h1);
            List<float> z01 = Interpolate(y0, z0, y1, z1);

            List<float> xlinea12 = Interpolate(y1, x1, y2, x2);
            List<float> h12 = Interpolate(y1, h1, y2, h2);
            List<float> z12 = Interpolate(y1, z1, y2, z2);

            List<float> xlinea02 = Interpolate(y0, x0, y2, x2);
            List<float> h02 = Interpolate(y0, h0, y2, h2);
            List<float> z02 = Interpolate(y0, z0, y2, z2);

            // Verifica si hay suficientes elementos y, de ser así, elimina el último
            if (xlinea01.Count >= 2)
                xlinea01.RemoveAt(xlinea01.Count - 1);

            // Crea una nueva lista combinando xlinea01 y xlinea12
            List<float> xlinea012 = new List<float>(xlinea01);
            xlinea012.AddRange(xlinea12);

            // Repite el proceso para h01 y h12
            if (h01.Count >= 2)
                h01.RemoveAt(h01.Count - 1);

            List<float> h012 = new List<float>(h01);
            h012.AddRange(h12);

            // Repite el proceso para z01 y z12
            if (z01.Count >= 2)
                z01.RemoveAt(z01.Count - 1);

            List<float> z012 = new List<float>(z01);
            z012.AddRange(z12);



            if (xlinea02.Count > 0 && xlinea012.Count > 0)
            {
                double md = 2 * xlinea02.Count / 3;
                int m = (int)Math.Floor(md);
                //m = Math.Min(xlinea02.Count, xlinea012.Count);
                if (m < 0) m = 1;
                List<float> x_left, x_right, h_left, h_right, z_left, z_right;
                if (xlinea02[m] < xlinea012[m])
                {
                    x_left = xlinea02;
                    h_left = h02;
                    z_left = z02;

                    x_right = xlinea012;
                    h_right = h012;
                    z_right = z012;
                }
                else
                {
                    x_left = xlinea012;
                    h_left = h012;
                    z_left = z012;

                    x_right = xlinea02;
                    h_right = h02;
                    z_right = z02;
                }
                List<float> h_segment, z_segment;
                // Dibujar los segmentos horizontales
                for (int y = (int)y0; y <= (int)y2; y++)
                {
                    int x_l = (int)x_left[y - (int)y0];
                    int x_r = (int)x_right[y - (int)y0];
                    h_segment = Interpolate(x_l, h_left[y - (int)y0], x_r, h_right[y - (int)y0]);
                    z_segment = Interpolate(x_l, z_left[y - (int)y0], x_r, z_right[y - (int)y0]);
                    for (int x = x_l; x <= x_r; x++)
                    {
                        float newRed = colorBase.R * h_segment[x - (int)x_l];
                        float newGreen = colorBase.G * h_segment[x - (int)x_l];
                        float newBlue = colorBase.B * h_segment[x - (int)x_l];

                        if (newRed > 255) newRed = 255;
                        if (newGreen > 255) newGreen = 255;
                        if (newBlue > 255) newBlue = 255;

                        if (newRed < 0) newRed = 0;
                        if (newGreen < 0) newGreen = 0;
                        if (newBlue < 0) newBlue = 0;

                        if(float.IsNaN(newRed)) newRed = 0;
                        if (float.IsNaN(newGreen)) newGreen = 0;
                        if (float.IsNaN(newBlue)) newBlue = 0;

                        Color FinalColor = Color.FromArgb(
                            (int)(newRed),
                            (int)(newGreen),
                            (int)(newBlue));

                        // Variables que definen los límites de la matriz
                        int width = canvas.zBuffer.GetLength(0);  // Obtiene la longitud en la dimensión X
                        int height = canvas.zBuffer.GetLength(1); // Obtiene la longitud en la dimensión Y

                        // Comprobación de si x y y están dentro de la matriz z buffer
                        if (x >= 0 && x < width && y >= 0 && y < height)
                        {
                            if (z_segment[x - x_l] >= canvas.zBuffer[x, y])
                            {
                                canvas.zBuffer[x, y] = z_segment[x - x_l];
                                canvas.DrawPixel(x, y, FinalColor);
                            }
                        }
                        
                    }
                }
            }
        }
        public static void SortByY2(ref PointF P0, ref PointF P1, ref PointF P2, ref float h0, ref float h1, ref float h2, ref float z0, ref float z1, ref float z2)
        {
            // Ordena primero P0 y P1 si es necesario
            if (P1.Y < P0.Y)
            {
                Swap(ref P1, ref P0);
                SwapH(ref h1, ref h0);
                SwapZ(ref z1, ref z0);
            }
            // Ordena P0 y P2 si es necesario (P0 podría haber cambiado en el paso anterior)
            if (P2.Y < P0.Y)
            {
                Swap(ref P2, ref P0);
                SwapH(ref h2, ref h0);
                SwapZ(ref z2, ref z0);
            }
            // Ordena P1 y P2 si es necesario. Ahora P0 es definitivamente el menor,
            // pero P1 y P2 podrían necesitar un ordenamiento adicional.
            if (P2.Y < P1.Y)
            {
                Swap(ref P2, ref P1);
                SwapH(ref h2, ref h1);
                SwapZ(ref z2, ref z1);
            }
        }
        public static void SwapH(ref float A, ref float B) {
            float temp = A;
            A = B;
            B = temp;
        }
        public static void SwapZ(ref float A, ref float B)
        {
            float temp = A;
            A = B;
            B = temp;
        }
        public static void Swap(ref PointF A, ref PointF B) {
            PointF temp = A;
            A = B;
            B = temp;
        }
        public static List<float> Interpolate(float i0, float d0, float i1, float d1)
        {
            List<float> values = new List<float>();

            // La cantidad de pasos a interpolar; ajusta este valor según sea necesario para mayor precisión.
            int steps = Math.Abs((int)i1 - (int)i0);
            if (steps == 0) steps = 1; // Asegura al menos un paso para evitar la división por cero.

            float deltaI = (i1 - i0) / steps;
            float deltaD = (d1 - d0) / steps;

            for (int step = 0; step <= steps; step++)
            {
                float interpolatedI = i0 + deltaI * step;
                float interpolatedD = d0 + deltaD * step;
                // Opcionalmente, puedes usar interpolatedI si es relevante para tu aplicación.
                values.Add(interpolatedD);
            }

            return values;
        }

    }
}
