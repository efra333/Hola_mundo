﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace PLAYGROUND
{
    public class Keyframe
    {
        public float kCenterX;
        public float kCenterY;
        public float kCenterZ;
        public float scale;
        public float kAlphaX;
        public float kAlphaY;
        public float kAlphaZ;
        public Keyframe(float keyframeCenterX, float keyframeCenterY, float keyframeCenterZ, float scale, float keyframeAngleX, float keyframeAngleY, float keyframeAngleZ)
        {
                 this.kCenterX = keyframeCenterX;
                this.kCenterY = keyframeCenterY;
            this.kCenterZ = keyframeCenterZ;
            this.scale = scale;
            this.kAlphaX = keyframeAngleX;
            this.kAlphaY = keyframeAngleY;
            this.kAlphaZ = keyframeAngleZ;
        }
    }
}
