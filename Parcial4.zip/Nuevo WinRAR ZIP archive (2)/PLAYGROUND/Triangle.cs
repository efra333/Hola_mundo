﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PLAYGROUND
{
    public class Triangle
    {
        public const int A = 0;
        public const int B = 1;
        public const int C = 2;
        public int[] Values = new int[3];
        public PointF edge1, edge2, edge3;
        public List<Vertex> Vertex;
        public List<Vertex> OriginalVertex;
        public List<PointF> Vertex2D;
        public List<float> hs;
        public Triangle(int VertexA, int VertexB, int VertexC)
        {
            Vertex = new List<Vertex>();
            OriginalVertex = new List<Vertex>();
            Vertex2D = new List<PointF>();
            hs = new List<float>() { 1,1,1};
            Values[0] = VertexA; 
            Values[1] = VertexB; 
            Values[2] = VertexC;
        }
        public void Edges(){
            edge1 = new PointF(Vertex2D[1].X - Vertex2D[0].X, Vertex2D[1].Y - Vertex2D[0].Y);
            edge2 = new PointF(Vertex2D[2].X - Vertex2D[1].X, Vertex2D[2].Y - Vertex2D[1].Y);
            edge3 = new PointF(Vertex2D[2].X - Vertex2D[0].X, Vertex2D[2].Y - Vertex2D[0].Y);
        }
        public Vertex Normal() {
            Vertex A = Vertex[0];
            Vertex B = Vertex[1];
            Vertex C = Vertex[2];

            Vertex AB = B - A;
            Vertex AC = C - A;

            Vertex normal = PLAYGROUND.Vertex.Cross(AB, AC);

            normal = normal.Normalize();

            return normal;
        }
    }
}
