﻿using PLAYGROUND.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLAYGROUND
{
    public class Canvas
    {
    public static int canvasWidth, canvasHeight;
    public static PictureBox pctCanvas;
    public Bitmap bitmap;
    public int Width, Height;
    public byte[] bits;
    public Graphics g;
    int pixelFormatSize, stride;
    public float[,] zBuffer; // Matriz de z-buffering
        public Canvas(PictureBox pctCanvas) {
            Canvas.pctCanvas = pctCanvas;
            Size size = pctCanvas.Size;
            Init(size.Width, size.Height);
            Canvas.pctCanvas.Image = bitmap;
        }
        private void Init(int width, int height)
        {
            PixelFormat format;
            GCHandle handle;
            IntPtr bitPtr;
            int padding;
            format = PixelFormat.Format32bppArgb;
            bitmap = new Bitmap(width, height);
            Width = width;
            canvasWidth = width;
            Height = height;
            canvasHeight = height;
            pixelFormatSize = Image.GetPixelFormatSize(format) / 8; // 8 bits = 1 byte
            stride = width * pixelFormatSize; // total pixels (width) times ARGB (4)
            padding = (stride % 4); // PADD = move every pixel in bytes
            stride += padding == 0 ? 0 : 4 - padding; // 4 byte multiple Alpha, Red, Green, Blue
            bits = new byte[stride * height]; // total pixels (width) times ARGB (4) times Height
            handle = GCHandle.Alloc(bits, GCHandleType.Pinned); // TO LOCK THE MEMORY
            bitPtr = Marshal.UnsafeAddrOfPinnedArrayElement(bits, 0);
            bitmap = new Bitmap(width, height, stride, format, bitPtr);
            g = Graphics.FromImage(bitmap); // Para hacer pruebas regulares

            zBuffer = new float[width, height];
            ClearZBuffer();
        }
        public void DrawPixel(int X, int Y, Color c) {
            if (X >= 0 && X < Width && Y >= 0 && Y < Height)
            {
                int res = (int)((X * pixelFormatSize) + (Y * stride));
                bits[res + 0] = c.B; // byte blue
                bits[res + 1] = c.G; // byte green
                bits[res + 2] = c.R; // byte red
                bits[res + 3] = 255; // byte alpha
            }
        }
        public void FastClear()
        {
            unsafe
            {
                BitmapData bitmapData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height),
                ImageLockMode.ReadWrite, bitmap.PixelFormat);
                int bytesPerPixel = System.Drawing.Bitmap.GetPixelFormatSize(bitmap.PixelFormat) / 8;
                int heightInPixels = bitmapData.Height;
                int widthInBytes = bitmapData.Width * bytesPerPixel;
                byte* PtrFirstPixel = (byte*)bitmapData.Scan0;
                bitmap.UnlockBits(bitmapData);
                Parallel.For(0, heightInPixels, y => // usando proceso en paralelo
                {
                    byte* bits = PtrFirstPixel + (y * bitmapData.Stride);
                    for (int x = 0; x < widthInBytes; x = x + bytesPerPixel)
                    {
                        bits[x + 0] = 0;// (byte)Blue;
                        bits[x + 1] = 0;// (byte)Green;
                        bits[x + 2] = 0;// (byte)Red;
                        bits[x + 3] = 0;// (byte)Red;
                    }
                });
            }
        }
        public void RefreshCanvas() { 
            Canvas.pctCanvas.Invalidate();
        }
        public void ClearZBuffer() 
        {
            Parallel.For(0, Width, x =>
            {
                int y;
                for (y = 0; y < (Height - (Height % 4)); y += 4)
                {
                    zBuffer[x, y] = float.MinValue;
                    zBuffer[x, y + 1] = float.MinValue;
                    zBuffer[x, y + 2] = float.MinValue;
                    zBuffer[x, y + 3] = float.MinValue;
                }

                for (; y < Height; y++)
                {
                    zBuffer[x, y] = float.MinValue;
                }
            });

        }
        int i = 0;
        public void Render(Scene scene) 
        {
            FastClear();
            ClearZBuffer();
            scene.RenderScene(this);
            if(MyForm.changeInvert) BitProcess.Invert(bits);
            RefreshCanvas();
        }
    }
}
